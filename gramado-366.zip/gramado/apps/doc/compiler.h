
// compiler.h

#ifndef __COMPILER_H
#define __COMPILER_H    1

FILE *compiler (int dump_output);

#endif    

