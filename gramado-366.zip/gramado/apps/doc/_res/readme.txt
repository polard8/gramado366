_res : resources for gramc/ (Gramado C Compiler.)
