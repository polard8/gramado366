
// editor.h

#ifndef __EDITOR_H
#define __EDITOR_H    1

// ...
#define IP(a, b, c, d) \
    (a << 24 | b << 16 | c << 8 | d)


int editor_initialize( int argc, char *argv[] );

#endif    

