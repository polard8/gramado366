
// globqals.c

#include "globals.h"

unsigned long gScreenWidth=0;
unsigned long gScreenHeight=0;


unsigned long windowList[WINDOW_COUNT_MAX];

// The display structure.
struct gws_display_d *Display;

