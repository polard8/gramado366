# gdm

Gramado Display Manager.

```
 * This is the display manager.
 * This is gonna be the first application launched by the window server.
 * The purpose is given support to logon and logoff.
 * We can use this application to setup the window server properly.
```
