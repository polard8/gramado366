// memory.h

#ifndef __MEMORY_H
#define __MEMORY_H    1

extern struct gws_display_d *Display;

#endif  

