rotinas de baixo nivel para suportarem stdio.c
principalmente envolvendo arquivos.. começam com '__'

