

 /sysdeps
  
       Rotinas dependentes de elementos específicos do sistema operacional.
       Pasta craida para ficar mais parecida com a glibc.