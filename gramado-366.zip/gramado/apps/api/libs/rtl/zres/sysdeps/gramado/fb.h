
// fb.h
// framebuffer control.
// Let's build some routines for controlling
// the standard Gramado display driver.
// We're gonna open a device file using open()
// and send some comands using ioctl().

// #todo
// We can use a structure to get a block of info.


