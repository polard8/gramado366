
// #todo
// crt0 for the shared library version of the libc.

void socrt0(void)
{
    //todo
}




