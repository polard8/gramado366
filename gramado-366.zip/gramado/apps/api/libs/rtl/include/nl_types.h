
// nl_types.h

#ifndef _NL_TYPES_H_
#define _NL_TYPES_H_

// ...

#endif	/* _NL_TYPES_H_ */


