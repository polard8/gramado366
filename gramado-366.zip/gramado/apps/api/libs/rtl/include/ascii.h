#ifndef _ANSI_H
#define _ANSI_H

//#define	_VOIDSTAR	void *
//#define	_VOID		void


//Credits: fred nora. (w).
//#define isascii(c) ((((c) & 0x7F) == (c)) ? 1 : 0)
//#define toascii(c) ((c) & 0x7F)


#endif /* ANSI_H */


