
// stdbool.h
// Definição do tipo de dado booleano.


#ifndef  __STDBOOL_H_
#define  __STDBOOL_H_

typedef int  bool;
#define _Bool  bool

// Is this a c++ thing?
#define false  0
#define true   1

/* Inform that everything is fine */
#define __bool_true_false_are_defined  1

#endif    


