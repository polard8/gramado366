

// fenv.h

// Controle de ponto flutuante.

