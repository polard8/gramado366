#define  sysname  "where I am"  

