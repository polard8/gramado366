


/*
 * Window/terminal size structure.  This information is stored by the kernel
 * in order to provide a consistent interface, but is not used by the kernel.
 */

// there is another one in termios.h
/*
struct winsize {
	unsigned short	ws_row;		 //rows, in characters 
	unsigned short	ws_col;		 // columns, in characters 
	unsigned short	ws_xpixel;	 // horizontal size, pixels 
	unsigned short	ws_ypixel;	 // vertical size, pixels 
};
*/


