
// tp_defs.h


char	mt[]	= "/dev/mt0";
char	tc[]	= "/dev/tapx";
//int	flags	= flu;
char	mheader[] = "/usr/mdec/mboot";
char	theader[] = "/usr/mdec/tboot";


