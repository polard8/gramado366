# libgws - API for the client-side GUI library.

```
  The client-side GUI applications are linked against this library 
in order to connect with the display server via socket for 
sending and receiving messages.
```

We include this library in the applications 
to make requests to the display server.

Client-side library for the Gramado Display Server.
This is the client-side library linked statically
agains the client applications.
Here we have routines for making the requests to the server
and getting the responses.

The API is divided in two major components: base/ and user/.
  base/ is system components and user/ in for interactive user components.
  



    
