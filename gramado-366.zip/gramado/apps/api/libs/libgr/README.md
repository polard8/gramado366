# libgr - Graphical library for client-side GUI applications.

Graphical library for client-side GUI applications.

```
 This library provides for the client-side GUI applications some 
basic 2D graphics support.
```

